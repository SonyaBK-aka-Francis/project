import pygame
import os
import sys


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        sys.exit()
    image = pygame.image.load(fullname)
    return image


class Knock(pygame.sprite.Sprite):
    image = load_image("letter.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Knock.image
        self.rect = self.image.get_rect()


class Look(pygame.sprite.Sprite):
    image = load_image("letter_look.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Look.image
        self.rect = self.image.get_rect()


class Enter(pygame.sprite.Sprite):
    image = load_image("letter_enter.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Enter.image
        self.rect = self.image.get_rect()


class Nikolaev(pygame.sprite.Sprite):
    image = load_image("letter_file1.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Nikolaev.image
        self.rect = self.image.get_rect()


class Vishnyakova(pygame.sprite.Sprite):
    image = load_image("letter_file2.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Vishnyakova.image
        self.rect = self.image.get_rect()


class Rybin(pygame.sprite.Sprite):
    image = load_image("letter_file3.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Rybin.image
        self.rect = self.image.get_rect()


class Sudnik(pygame.sprite.Sprite):
    image = load_image("letter_file4.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Sudnik.image
        self.rect = self.image.get_rect()


class Dialogue(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__(all_sprites)
        if char.bl1 and bg1:
            self.image = load_image(f"{dls['door_301']}.png")
        elif char.bl2 and bg1:
            self.image = load_image(f"{dls['door_302']}.png")
        elif char.bl3 and bg1:
            self.image = load_image(f"{dls['door_303']}.png")
        elif char.bl1 and bg2:
            self.image = load_image(f"{dls['door_304']}.png")
        elif char.bl2 and bg2:
            self.image = load_image(f"{dls['door_305']}.png")
        elif char.bl3 and bg2:
            self.image = load_image(f"{dls['door_306']}.png")
        elif char.bl1 and bg3:
            self.image = load_image(f"{dls['door_307']}.png")
        elif char.bl2 and bg3:
            self.image = load_image(f"{dls['door_308']}.png")
        elif archive:
            if char.fe1:
                self.image = load_image(f"{dls['archive1']}.png")
            elif char.fe2:
                self.image = load_image(f"{dls['archive2']}.png")
            elif char.fe3:
                self.image = load_image(f"{dls['archive3']}.png")
            elif char.fe4:
                self.image = load_image(f"{dls['archive4']}.png")
        self.rect = self.image.get_rect()

    def update(self, *args):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                self.rect.x = 0
                self.rect.y = 0


class Blank1(pygame.sprite.Sprite):
    image = load_image("blank.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Blank1.image
        self.rect = self.image.get_rect()
        self.rect.x = 220
        self.rect.y = 328

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class Blank2(pygame.sprite.Sprite):
    image = load_image("blank.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Blank2.image
        self.rect = self.image.get_rect()
        self.rect.x = 679
        self.rect.y = 329

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class Blank3(pygame.sprite.Sprite):
    image = load_image("blank.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Blank3.image
        self.rect = self.image.get_rect()
        self.rect.x = 1143
        self.rect.y = 329

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class File1(pygame.sprite.Sprite):
    image = load_image("Папка 1.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = File1.image
        self.rect = self.image.get_rect()
        self.rect.x = 270
        self.rect.y = 191

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class File2(pygame.sprite.Sprite):
    image = load_image("Папка 2.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = File2.image
        self.rect = self.image.get_rect()
        self.rect.x = 804
        self.rect.y = 325

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class File3(pygame.sprite.Sprite):
    image = load_image("Папка 3.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = File3.image
        self.rect = self.image.get_rect()
        self.rect.x = 590
        self.rect.y = 192

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


class File4(pygame.sprite.Sprite):
    image = load_image("Папка 4.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = File4.image
        self.rect = self.image.get_rect()
        self.rect.x = 1151
        self.rect.y = 261

        # вычисляем маску для эффективного сравнения
        self.mask1 = pygame.mask.from_surface(self.image)


# poster
class Poster(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        self.image = load_image("постер.png")
        self.rect = self.image.get_rect()

    def update(self, *args):
        self.rect.x = 810
        self.rect.y = 130
        self.mask1 = pygame.mask.from_surface(self.image)

        # вычисляем маску для эффективного сравнения


class Char(pygame.sprite.Sprite):

    def __init__(self, size, group):
        super().__init__()
        self.bl1 = False
        self.bl2 = False
        self.bl3 = False
        self.bl4 = False
        self.fe1 = False
        self.fe2 = False
        self.fe3 = False
        self.fe4 = False
        self.image = load_image("char.png")
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 170
        self.speed = 1  # speed
        self.l_pressed = False
        self.r_pressed = False
        self.mask = pygame.mask.from_surface(self.image)

        self.move_right = [pygame.transform.flip(load_image("move1.png"), True, False),
                           pygame.transform.flip(load_image("move2.png"), True, False)]

        self.move_left = [load_image("move1.png"),
                          load_image("move2.png")]

        self.l_move_count = 0
        self.r_move_count = 0

        self.velocity = self.speed
        self.size = size  # size
        group.add(self)  # sprite group
        self.flipped_image = pygame.transform.flip(self.image, True, False)

    def update(self, *args):
        # Move
        # arrow buttons
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.l_pressed = True
                self.r_pressed = False
                self.image = self.move_left[self.l_move_count]
                self.rect.x -= 5
                if self.rect.left < 0:  # left edge
                    self.rect.left = 0

                if pygame.sprite.collide_mask(self, blank[0]):
                    self.bl1 = True
                else:
                    self.bl1 = False

                if pygame.sprite.collide_mask(self, blank[1]):
                    self.bl2 = True
                else:
                    self.bl2 = False

                if pygame.sprite.collide_mask(self, blank[2]):
                    self.bl3 = True
                else:
                    self.bl3 = False

                if archive:
                    self.image = load_image("back.png")

                    if pygame.sprite.collide_mask(self, files[0]):
                        self.fe1 = True
                    else:
                        self.fe1 = False

                    if pygame.sprite.collide_mask(self, files[1]):
                        self.fe2 = True
                    else:
                        self.fe2 = False

                    if pygame.sprite.collide_mask(self, files[2]):
                        self.fe3 = True
                    else:
                        self.fe3 = False

                    if pygame.sprite.collide_mask(self, files[3]):
                        self.fe4 = True
                    else:
                        self.fe4 = False

            elif event.key == pygame.K_RIGHT:
                self.l_pressed = False
                self.r_pressed = True
                self.image = self.move_right[self.r_move_count]
                self.rect.x += 5

                if self.rect.right > 1260:  # check if the char reached the right edge of the screen
                    self.rect.right = 1260

                if pygame.sprite.collide_mask(self, blank[0]):
                    self.bl1 = True
                else:
                    self.bl1 = False

                if pygame.sprite.collide_mask(self, blank[1]):
                    self.bl2 = True
                else:
                    self.bl2 = False

                if pygame.sprite.collide_mask(self, blank[2]):
                    self.bl3 = True
                else:
                    self.bl3 = False

                if archive:
                    self.image = load_image("back.png")

                    if pygame.sprite.collide_mask(self, files[0]):
                        self.fe1 = True
                    else:
                        self.fe1 = False

                    if pygame.sprite.collide_mask(self, files[1]):
                        self.fe2 = True
                    else:
                        self.fe2 = False

                    if pygame.sprite.collide_mask(self, files[2]):
                        self.fe3 = True
                    else:
                        self.fe3 = False

                    if pygame.sprite.collide_mask(self, files[3]):
                        self.fe4 = True
                    else:
                        self.fe4 = False
        else:
            if self.l_pressed:
                self.image = load_image("char.png")
            elif self.r_pressed and not archive:
                self.image = self.flipped_image
            if pygame.sprite.collide_mask(self, blank[0]):
                self.bl1 = True
            else:
                self.bl1 = False

            if pygame.sprite.collide_mask(self, blank[1]):
                self.bl2 = True
            else:
                self.bl2 = False

            if pygame.sprite.collide_mask(self, blank[2]):
                self.bl3 = True
            else:
                self.bl3 = False

            if archive:
                self.image = load_image("back.png")

                if pygame.sprite.collide_mask(self, files[0]):
                    self.fe1 = True
                else:
                    self.fe1 = False

                if pygame.sprite.collide_mask(self, files[1]):
                    self.fe2 = True
                else:
                    self.fe2 = False

                if pygame.sprite.collide_mask(self, files[2]):
                    self.fe3 = True
                else:
                    self.fe3 = False

                if pygame.sprite.collide_mask(self, files[3]):
                    self.fe4 = True
                else:
                    self.fe4 = False


if __name__ == '__main__':
    pygame.init()

    size = width, height = 1280, 720
    screen = pygame.display.set_mode(size)

    all_sprites = pygame.sprite.Group()
    blank = [Blank1(), Blank2(), Blank3()]

    char = Char(size, all_sprites)

    bg = pygame.transform.scale(load_image("фон1.png").convert(), (1280, 720))

    # flags for dialogue
    dial = False
    check_f1 = False
    check_f2 = False
    check_f3 = False
    check_f4 = False
    end_f1 = False
    end_f2 = False
    end_f3 = False
    end_f4 = False

    # flags for letter 'e'
    let = False
    let2 = False
    let3 = False
    let_enter = False
    let_look = False
    let_f1 = False
    let_f2 = False
    let_f3 = False
    let_f4 = False

    # flags for locations
    bg1 = True
    bg2 = False
    bg3 = False
    archive = False

    dls = {'door_301': '301_start',
           'door_302': '302_start',
           'door_303': '303_start',
           'door_304': '304_start',
           'door_305': '305_start',
           'door_306': '306_start',
           'door_307': '307_start',
           'door_308': '308_start',
           'archive1': 'dial_file1',
           'archive2': 'dial_file2',
           'archive3': 'dial_file3',
           'archive4': 'dial_file4',
           'poster': 'poster'}

    sound = pygame.mixer.Sound('44621039.mp3')
    sound.play(-1)

    sound_knock = pygame.mixer.Sound("stuk-v-dver-kostyashkami-paltsev.mp3")

    paused = False
    fps = 60
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if char.bl1 and not let and not archive:
                knock = Knock()
                let = True
            elif not char.bl1 and let and not dial:
                knock.kill()
                let = False

            elif char.bl2 and not let2 and not archive:
                knock = Knock()
                let2 = True
            elif not char.bl2 and let2 and not dial:
                knock.kill()
                let2 = False

            elif char.bl3 and not let_enter and bg3 and not archive:
                enter = Enter()
                let_enter = True
            elif not char.bl3 and let_enter and not dial:
                enter.kill()
                let_enter = False

            elif char.bl3 and not let3 and not let_enter and not bg3 and not archive:
                knock = Knock()
                let3 = True
            elif not char.bl3 and let3 and not dial:
                knock.kill()
                let3 = False

            elif char.bl4 and not let_look and bg3 and not archive:
                look = Look()
                let_look = True
            elif not char.bl4 and let_look and not dial:
                look.kill()
                let_look = False

            if archive:
                if char.fe1 and not let_f1:
                    f1 = Nikolaev()
                    let_f1 = True
                elif not char.fe1 and let_f1 and not dial:
                    f1.kill()
                    let_f1 = False

                elif char.fe2 and not let_f2:
                    f2 = Vishnyakova()
                    let_f2 = True
                elif not char.fe2 and let_f2 and not dial:
                    f2.kill()
                    let_f2 = False

                elif char.fe3 and not let_f3:
                    f3 = Rybin()
                    let_f3 = True
                elif not char.fe3 and let_f3 and not dial:
                    f3.kill()
                    let_f3 = False

                elif char.fe4 and not let_f4:
                    f4 = Sudnik()
                    let_f4 = True
                elif not char.fe4 and let_f4 and not dial:
                    f4.kill()
                    let_f4 = False

            if char.bl1 is True and bg1 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        if not check_f4:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                        elif check_f4:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl1:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl2 is True and bg1 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        knock.kill()
                        dialogue = Dialogue()
                        dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl2:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl3 is True and bg1 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        knock.kill()
                        dialogue = Dialogue()
                        dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl3:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl1 is True and bg2 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        knock.kill()
                        dialogue = Dialogue()
                        dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl1:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl2 is True and bg2 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        if not check_f1:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                        elif check_f1:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl2:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl3 is True and bg2 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        if not check_f2:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                        elif check_f2:
                            sound_knock.play()
                            knock.kill()
                            pygame.time.wait(1000)
                            dialogue = Dialogue()
                            dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl3:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl1 is True and bg3 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        sound_knock.play()
                        knock.kill()
                        pygame.time.wait(1000)
                        dialogue = Dialogue()
                        dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl1:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl2 is True and bg3 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        knock.kill()
                        dialogue = Dialogue()
                        dial = True
                elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False
            if not char.bl2:
                if event.type == pygame.MOUSEBUTTONDOWN and dial:
                    dialogue.kill()
                    dial = False

            if char.bl3 is True and bg3 is True:
                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_e:
                        enter.kill()
                        bg = pygame.transform.scale(load_image("архив1.png").convert(), (1280, 720))
                        archive = True
                        bg3 = False
                        bg2 = False
                        bg1 = False
                        blank[0].kill()
                        blank[1].kill()
                        blank[2].kill()
                        char.kill()
                        files = [File1(), File2(), File3(), File4()]
                        char = Char(size, all_sprites)

            if archive:
                if char.fe1 is True:
                    if event.type == pygame.KEYDOWN and not dial:
                        if event.key == pygame.K_e:
                            check_f1 = True
                            dls['door_305'] = '305_end'
                            f1.kill()
                            dialogue = Dialogue()
                            dial = True
                    elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False
                if not char.fe1:
                    if event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False

                if char.fe2 is True:
                    if event.type == pygame.KEYDOWN and not dial:
                        if event.key == pygame.K_e:
                            check_f2 = True
                            dls['door_306'] = '306_end'
                            f2.kill()
                            dialogue = Dialogue()
                            dial = True
                    elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False
                if not char.fe2:
                    if event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False

                if char.fe3 is True:
                    if event.type == pygame.KEYDOWN and not dial:
                        if event.key == pygame.K_e:
                            check_f3 = True
                            f3.kill()
                            dialogue = Dialogue()
                            dial = True
                    elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False
                if not char.fe3:
                    if event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False

                if char.fe4 is True:
                    if event.type == pygame.KEYDOWN and not dial:
                        if event.key == pygame.K_e:
                            check_f4 = True
                            dls['door_301'] = '301_end'
                            f4.kill()
                            dialogue = Dialogue()
                            dial = True
                    elif event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False
                if not char.fe4:
                    if event.type == pygame.MOUSEBUTTONDOWN and dial:
                        dialogue.kill()
                        dial = False

                if event.type == pygame.KEYDOWN and not dial:
                    if event.key == pygame.K_ESCAPE:
                        bg = pygame.transform.scale(load_image("фон3.png").convert(), (1280, 720))
                        archive = False
                        char.kill()
                        files[0].kill()
                        files[1].kill()
                        files[2].kill()
                        files[3].kill()
                        blank = [Blank1(), Blank2(), Blank3()]
                        char = Char(size, all_sprites)
                        char.rect.x = 1000
                        char.rect.y = 170
                        bg3 = True
                        bg1 = False
                        bg2 = False

            if char.rect.right == 1260 and bg1:
                bg = pygame.transform.scale(load_image("фон2.png").convert(), (1280, 720))
                bg1 = False
                bg2 = True
                char.rect.x = 5
            elif char.rect.right == 1260 and bg2:
                bg = pygame.transform.scale(load_image("фон3.png").convert(), (1280, 720))
                bg2 = False
                bg3 = True
                char.rect.x = 5
            elif char.rect.left == 0 and bg2:
                bg = pygame.transform.scale(load_image("фон1.png").convert(), (1280, 720))
                bg2 = False
                bg1 = True
                char.rect.x = 1000
            elif char.rect.left == 0 and bg3:
                bg = pygame.transform.scale(load_image("фон2.png").convert(), (1280, 720))
                bg3 = False
                bg2 = True
                char.rect.x = 1000

        all_sprites.update()
        screen.blit(bg, (0, 0))
        all_sprites.draw(screen)

        pygame.display.flip()
        clock.tick(60)
    pygame.quit()
